<?php
require("Includes/db.inc.php");
if (! isset ($_GET["cat"])) {
	header("Location: error.php");
}
$cat = $_GET["cat"];

$qry= "Select * from Locations Where LocationID like'". $cat ."';";
$rs= $mysqli->query($qry) or die ('Query1 failed:' .$mysqli->error . '<br>');

$row=$rs->fetch_assoc();
$Lname= $row["LocationCountry"];
$Limage= $row["LocationImage"];


include("includes/header.php");
include("includes/menu.php");


?>
<div id="content">






<h2><span><?php echo $Lname;?></span></h2>
<table style='width:80%; margin: auto;'>
<tr>

<td ALIGN=CENTER><img src="<?php echo $row["LocationImage"]; ?>"
 WIDTH=240 HEIGHT=180 ALIGN=CENTER></td>
<!-- insert retrieved item description into page heading-->
</tr>
</table>
<!--table and from displaying inventory data -->
<table style='width:80%; margin: auto;' class='listTable'>
<caption>Destination Details</caption>
<thead>
<tr>
<th style='width:20%; text-align: center'>DestinationID</th>
<th style='width:20%; text-align: center'>DestinationName</th>
<th style='width:20%; text-align: center'>DestinationPoints</th>
<th style='width:20%; text-align: center'>DestinationDesc</th>
</tr>
</thead>
<tbody>
<?php
$qry ='Select * from DestinationPoints Where DestinationID=" .$item. " AND LocationID=".$cat.";';

$rs=$mysqli->query($qry)
or die('Query2 failed: ' . $mysqli->error . '<br>');
$counter =0;
while ($row=$rs->fetch_assoc()){
$id=$row["DestinationID"];
$name=$row["DestinationName"];
$points=["DestinationPoints"];
$location=["DestinationLocation"];
if($counter==0){
echo"<tr style='text align:center;'>";
echo "<td><input name='item' value='".$id."|".$name."|".$points."|".$locations."|'</td><td>".$id."</td>";
echo "<td>".$name."</td><td>".$points."</td>";
}else{
	header('location:error.php?er=0');

//echo "<td><input name='item' value='".$id."|".$name."|".$points."|".$locations."|'</td><td>".$id."</td>".$name."</td>";
}}
?>
</tbody>
</table>
 </div>
<?php include("includes/dbend.inc.php");?>
<?php require("includes/footer.php");?>