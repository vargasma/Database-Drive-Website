<?php
   $title= "Thank you for your feecback/comments!";
   include ("includes/header.php");
?> 
<html>
<body>
Thank you <?php echo $_POST["name"]; ?> <br/>
Your request from <?php echo $_POST ["email"] ?> has been recieved. <br/>
We appreciate your feedback of "<?php echo $_POST["message"]; ?>". This will be reviewed shortly. 
</body>
<?php include("Includes/footer.php"); ?>

</html>


