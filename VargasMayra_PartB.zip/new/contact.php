﻿<?php $Variable="Contact" ?>
<?php include("includes/header.php"); ?>
<?php include("Includes/menu.php"); ?>
<div id="content">
  <h2>Contact Us</h2>
  <p>Please contact us if you have any questions or concerns.&nbsp; </p>
  <p><a href="mailto:your.name@ucdenver.edu">Mayra.Vargas@ucdenver.edu or at 720-123-4567</a> </p>
  <p>A <strong>SoloTraveler</strong> team member will respond to your email within 24 hours.</p>
  
  <form action = "Thankyou.php" method="POST">
  <form id = "contact" method="post">
  
  <div class="field">
     <label for="name">Name:</label>
	 <input type="text" id="name" name="name" required>
	 </div>
	 
  <div class="field">
     <label for="email">Email:</label>
	 <input type="email" id="email" name="email" required>
  </div  
  
  <div class="field">
     <label for="message">Message:</label>
	 <textarea id="message" name="message" required></textarea>
  </div

  <div class="field">
	<button type="submit">Send</button>
  </div>	

  </form>
</div> <!-- end content -->
<?php include("Includes/footer.php"); ?>