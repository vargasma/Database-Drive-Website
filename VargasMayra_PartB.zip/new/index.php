﻿<?php $Variable="Home"?>
<?php include("includes/header.php"); ?>
<?php include("Includes/menu.php"); ?>
<div id="content">
  <h2>Adventure Begins Here:</h2>
  <p>The <strong>SoloTraveler</strong> is the first step to paradise. We include all of the resources that are needed
  to make your trip easier. We focus on the tedius planning and price comparisons so that all you have to focus on is
  enjoying your time in a new world! We make touring easier, whether you travel solo or in a group. SoloTraveler is a 
  safe and trusting place to plan your next trip!
  </p>
		<p>Join the <strong>StudentClub</strong> to enhance your campus 
		experiences, meet new people and just have a good time.</p>
  <p class="center"> 
  <img alt="" height="205" src="travel.jpg" width="660" /><p> 
  
  
</div>
	<!-- end content -->
<?php include("Includes/footer.php"); ?>