<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $Variable; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="stylesheet" type="text/css" href="style1.css" />
</head>
<body>
<div id="layout">
<div id="header">
  <div id="logo">
    <h1>SoloTraveler.org</h1>
  </div> <!-- end logo -->
  <div id="tagline">
    <p>Become a Citizen of the World...</p>
  </div> <!-- end tagline -->
</div> <!-- end header -->