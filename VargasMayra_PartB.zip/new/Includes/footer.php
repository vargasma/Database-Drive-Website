<div id="footer">
  <p><?php date_default_timezone_set ("America/Denver" )?>
 Copyright <?php echo date ("Y")  ?> Mayra Vargas </p>
</div>
</div><!-- end layout -->
</body>
</html>