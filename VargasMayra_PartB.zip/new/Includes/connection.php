<?php
//$mysqli = new mysqli('198.71.225.60:3306','mvargas','mV100494898', 'mvargas')
//    or die( '<h2>Could not connect to MySQL with mysqli</h2></body></html>');
$mysqli = new mysqli('localhost','root','mysql', 'Locations')
    or die( '<h2>Could not connect to MySQL with mysqli</h2></body></html>');
echo "Success";

?>