<?php
mysqli_close($mysqli);
?>