<div id="nav">
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="about.php">About Us</a></li>
    <li><a href="contact.php">Contact Us</a></li>
	<li><a href="lists.php">Locations</a></li>
  </ul>
</div> <!-- end of nav -->