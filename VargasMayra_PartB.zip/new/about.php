﻿<?php $Variable="About"?>
<?php include("includes/header.php"); ?>
<?php include("Includes/menu.php"); ?>
<div id="content">
  
  <h2>About Us</h2>
    <p>The <strong>SoloTraveler</strong> is a place to help those with huge wanderlust get by in different cities. We can guide you to the 
best food in town, hotel recommendations, Travel tips,Maps and guides, Public transport info, Airport information
, Language and local dialect and much more!	</p>
	<p>It' simple! Depending on which country and city you would like to, our serch engine will guide you to possibilities on
future adventures that await you. To make the process more personalized, your information will be needed. This will guide
our team to display personalized results that fits best with what you are looking for. All journeys have secret destinations 
of which the traveler is unaware. We are here to open these new worlds to you. Start here, adventure awaits. 	</p>
  <p>&nbsp;</p>
  <h3>Who We Are:</h3>
 <p> <?php 
 
	$Text=array("CEO"=>"Mayra Vargas","CFO"=>"Rafel Garcia","CMO"=>"Michel Smith");	
	
	foreach($Text as $key => $Variable) {
	echo "$key : $Variable<br>"; } ?>

		
  

</div> <!-- end content -->
<?php include("Includes/footer.php"); ?>