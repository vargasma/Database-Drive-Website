<?php require("Includes/header.php"); ?>
<?php require("Includes/menu.php"); ?>
<style>
table, th, td{
	border-collapse: collapse;
    border: 1px solid #7D26CD;
border-width: 2px;
 background-color: #f3e7f3;
 

}
caption {
	font-size: 16px;
	padding-bottom: 20px;
	color: #FFC300;
	font-weight:bold;
}
</style>
<div id="content">
  
  <table width"600" border=0 cellpadding=5 cellspacing=0 align="center" >
 <caption ALIGN=CENTER>Available Locations:</caption>
<?php
     
include('Includes/db.inc.php');

   $qry = "Select * from Locations ";


   $rs = $mysqli->query($qry);
echo 
'<table #FF5733 align="center" width="900" >';
echo"<tr><th>LocationCity</th><th>LocationCountry</th><th>LocationImage</th><th>LocationID</th></tr>";
   // Loop through results set"
   while($row = $rs->fetch_assoc())
   { 
?>
<tr>
<td ALIGN=CENTER><?php echo $row["LocationCity"];?></td>
<td ALIGN=CENTER><?php echo $row["LocationCountry"];?></td>
 <td ALIGN=CENTER width="80">
   <img src="<?php echo $row["LocationImage"]; ?>" 
        width="80" height="80"></td>
<td><a href="details.php?cat=<?php echo $row['LocationID'] ?>"><?php echo $row ["LocationID"]; ?></a></td>

</tr>
<?php 
};
// end of while loop
 include("Includes/dbend.inc.php");
 
 echo "</table>"; 
?> 
  
  
</div>
<?php require("includes/footer.php"); ?>