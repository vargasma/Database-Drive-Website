<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php require("includes/header.php"); ?>
<?php require("includes/menu.php"); ?>

<?php
$title= "SoloTraveler - Become a Citizen of the World...";
?>

<?php
$title= "Error: Does Not Exist";
echo $title;
 
if (@$_GET['er']!=null){
if($_GET['er']==0){
echo'<h1> Deatils page not found</h1>';
}elseif($_Get['er'] ==1){
echo '<h1 Location does Not  exist!</h1>';}
else{echo'<h1> error! The page is not found</h1>';
}}
?>
  
</div>
<?php require("includes/footer.php"); ?>