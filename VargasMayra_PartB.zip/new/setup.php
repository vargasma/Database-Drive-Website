<?php
$array[0] = "CREATE TABLE IF NOT EXISTS `Locations` (`LocationID` int(5) NOT NULL, `LocationCountry` varchar(20) NOT NULL, `LocationCity` varchar(30) NOT NULL, `LocationImage` text NOT NULL);";

$array[1]="INSERT INTO `Locations` (LocationID, LocationCountry, LocationCity, LocationImage) VALUES(1, 'France', 'Paris', 'France.jpg'),(2, 'Spain', 'Barcelona', 'Spain.jpg'),(3, 'United Arab Emirates', 'Dubai', 'UAE.jpg'),(4, 'Mexico', 'Guadalajara', 'Mexico.jpg');";

$array[2]="CREATE TABLE IF NOT EXISTS `DestinationPoints` (`DestinationID` int(5) NOT NULL, `DestinationName` varchar(100) NOT NULL,  `DestinationPoints` int(20) NOT NULL,  `DestinationDesc` varchar(100) NOT NULL,  `LocationID` int(5) NOT NULL);";
$array[3]="INSERT INTO `DestinationPoints` (DestinationID, DestinationName, DestinationPoints, DestinationDesc,LocationID) VALUES (1, 'Eiffel Tower', '150', 'Landmark', '1'),(2, 'The Louvre', '20', 'Museum', '1'),(3, 'Arc De Triomphe', '30', 'Monument', '1'),(4, 'Camp Nou', '100', 'Stadium', '2'),(5, 'Museu Nacional dart de Catalunya', '50 ', 'Museum', '2'),(6, 'Parc Del Labrint Dhorta', '40', 'Park', '2'),(7, 'Burj Khalifa', '200', 'Skyscraper', '3'),(8, 'Burj Al Arab', '100', 'Hotel with Dining', '3'),(9, 'Dubai Mall', '50', 'Shopping Center', '3'),(10, 'San Juan de Dios Market', '50', 'Market', '4'),(11, 'Puerta Vallarta', '250', 'Beach', '4'),(12, 'Rotonda De Los Jaliscienses Ilustres', '30', 'Monument', '4');";

$mysqli = new mysqli('198.71.225.60:3306','mvargas','mV100494898', 'mvargas')
    or die( '<h2>Could not connect to MySQL with mysqli</h2></body></html>');
	
  foreach($array as $value) {
	echo $value."<br>";  // notice variable embedded
    $mysqli->query($value) or die('Query failed:'.$conn->error.'<br>');}

	mysqli_close($mysqli);              

?>

	